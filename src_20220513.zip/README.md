This is a puzzle game `Quickness Test! 1 to 50` demo app

REF: [zzzscore.com](https://zzzscore.com/1to50/en/)

## Getting Started
First, clone the [repository](https://github.com/imranwijaya/expressjs-puzzle-game-1to50-demo) & install the dependencies:

```bash
#clone github repository
git clone https://github.com/imranwijaya/expressjs-puzzle-game-1to50-demo.git

#after successful clone
npm install
```

Running the app
```bash
#run app
npm run start
```